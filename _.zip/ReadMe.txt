Code files are present for Chapter 8, Logging and Real-time Analytics with MongoDB, only.

To successfully understand every chapter on this book, you need access to a MongoDB 3.0 instance.

In Chapter 8, Logging and Real-time Analytics with MongoDB, you will need to have Node.js installed on your machine and it should have access to your MongoDB instance. 